import json
from scraper import Scraper

def lambda_handler(event, context):
    scraper = Scraper()
    scraper.run()
    return {
        'statusCode': 200,
        'body': json.dumps('Database has been updated')
    }
