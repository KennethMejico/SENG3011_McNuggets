import json
from datetime import datetime

# I have absolutely no idea why this is necessary but list was refusing to import addLog but will import add
def add(results):
    return addLog(results)

def noneOrEmpty(str):
    return (str is None) or (not str)
    
def page_not_found():
    return json.dumps("The resource could not be found")

def dates_not_given():
    return json.dumps("Please input a start and end date.")
    
def getLocationsForReport(reportId, cursor, location=None):
    locationQuery = """
        SELECT l.LocationName
        FROM Locations l 
        join Report_Locations rl on rl.LocationID = l.LocationID
        join Reports r on rl.ReportID = r.ReportID
        where r.ReportID = %s
    """

    locationData = (reportId,)
    if not noneOrEmpty(location):
        locationQuery = locationQuery + " and l.locationName LIKE %s"
        formatted_location = "%" + location + "%"
        locationData = locationData + (formatted_location,)
    
    cursor.execute(locationQuery, locationData)
    results = cursor.fetchall()

    locations = []
    for location in results:
        locations.append(location[0])

    return locations

def getDiseasesForReport(reportId, cursor, key_terms=None):
    query = """
        SELECT d.DiseaseName
        FROM Diseases d 
        join Report_Diseases rd on rd.DiseaseID = d.DiseaseID
        join Reports r on rd.ReportID = r.ReportID
        where r.ReportID = %s
    """

    data = (reportId,)    
    cursor.execute(query, data)
    results = cursor.fetchall()

    diseases = []
    for disease in results:
        diseases.append(disease[0].lower())

    return diseases

def getSyndromesForReport(reportId, cursor, key_terms=None):
    query = """
        SELECT s.SyndromeName
        FROM Syndromes s
        join Report_Syndromes rs on rs.SyndromeID = s.SyndromeID
        join Reports r on rs.ReportID = r.ReportID
        where r.ReportID = %s
    """

    data = (reportId,)
    
    cursor.execute(query, data)
    results = cursor.fetchall()

    syndromes = []
    for syndrome in results:
        syndromes.append(syndrome[0].lower())

    return syndromes

def addLog(results):
    log = {
        "team_name": "McNuggets",
        "accessed_time": datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
        "data_source": "promedmail.org"
    }

    response = {
        "log": log,
        "response": results
    }

    return response