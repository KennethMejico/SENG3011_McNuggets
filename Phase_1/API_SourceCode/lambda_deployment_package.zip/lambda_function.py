import json, traceback
from search import filter_search
from count import get_count
import list
from helpers import add

def home(params):
    return json.dumps(add({
        "function": "",
        "endpoints": ["/search", "/count", "/list"]
    }))

def lambda_handler(event, context):
    try:
        body = "Failed to find resource: \"" + event["path"] + "\""
        contentType = "text/html"
        if event["path"] == "/mcnuggets":
            body = home(event["queryStringParameters"])
        elif event["path"] == "/mcnuggets/search":
            body = filter_search(event["queryStringParameters"])
            contentType = "application/json"
        elif event["path"] == "/mcnuggets/count":
            body = get_count(event["queryStringParameters"])
            contentType = "application/json"
        elif event["path"] == "/mcnuggets/list":
            body = list.home(event["queryStringParameters"])
            contentType = "application/json"
        elif event["path"] == "/mcnuggets/list/diseases":
            body = list.get_all_diseases(event["queryStringParameters"])
            contentType = "application/json"
        elif event["path"] == "/mcnuggets/list/locations":
            body = list.get_all_locations(event["queryStringParameters"])
            contentType = "application/json"
        elif event["path"] == "/mcnuggets/list/reports":
            body = list.get_all_reports(event["queryStringParameters"])
            contentType = "application/json"
        elif event["path"] == "/mcnuggets/list/syndromes":
            body = list.get_all_syndromes(event["queryStringParameters"])
            contentType = "application/json"

        if body == "Failed to find resource: \"" + event["path"] + "\"":
            return {
                'statusCode': 404,
                'headers': { 
                      'Access-Control-Allow-Origin': '*'
                },
                'body': body
            }
        return {
            'statusCode': 200,
            'headers': { 
                  'Content-Type': 'application/json',
                  'Access-Control-Allow-Origin': '*'
            },
            'body': body
        }
    except Exception as e:
        return {
            'statusCode': 502,
            'headers': { 
                  'Content-Type': 'application/json',
                  'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                "message": str(e),
                "trace": traceback.format_exc()
            })
        }
        