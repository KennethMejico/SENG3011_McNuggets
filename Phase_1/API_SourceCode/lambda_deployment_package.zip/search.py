import json
from datetime import datetime
import db_controller
from helpers import noneOrEmpty, dates_not_given, getDiseasesForReport, getLocationsForReport, getSyndromesForReport, addLog

def filter_search(query_parameters):
    # Retrieve parameters
    if "start_date" in query_parameters:
        start_date = query_parameters['start_date']
    else:
        start_date = None
    if "end_date" in query_parameters:
        end_date = query_parameters['end_date']
    else:
        end_date = None
    if "key_terms" in query_parameters:
        key_terms = query_parameters['key_terms']
    else:
        key_terms = None
    if "location" in query_parameters:
        location = query_parameters['location']
    else:
        location = None

    if noneOrEmpty(start_date) or noneOrEmpty(end_date):
        return dates_not_given()
    
    result = search(start_date, end_date, location, key_terms, db_controller.getDbConnection())

    # Return list of articles
    return json.dumps(addLog(result))

def search(start_date, end_date, location, key_terms, db):
    mycursor = db.cursor()

    # Base SQL Query
    sql = """
        select
            a.LinkToArticle,
            a.PubDate,
            a.ArticleName,
            a.MainText,
            r.EventDate,
            r.ReportID
        from Articles a
        join Reports r on r.ArticleID = a.ArticleID
        where a.ArticleID = a.ArticleID
    """
    data = ()
    if not noneOrEmpty(start_date):
        # Convert start date time to datetime datatype
        start = datetime.strptime(start_date, '%Y-%m-%dT%H:%M:%S')
        sql = sql + " and a.PubDate >= %s"
        data = data + (start,)

    if not noneOrEmpty(end_date):
        end = datetime.strptime(end_date, '%Y-%m-%dT%H:%M:%S')
        sql = sql + " and a.PubDate <= %s"
        data = data + (end,)

    mycursor.execute(sql, data)
    results = mycursor.fetchall()
    result_list = []
    for result in results:
        report_list = []
        reportId = result[5]
        locations = getLocationsForReport(reportId, mycursor, location)
        diseases = getDiseasesForReport(reportId, mycursor, key_terms)
        syndromes = getSyndromesForReport(reportId, mycursor, key_terms)
        
        if not noneOrEmpty(location) and len(locations) == 0:
            continue
        if not noneOrEmpty(key_terms) and len(diseases) == 0 and len(syndromes) == 0:
            continue

        report = {
            'event_date': result[4].strftime("%c"),
            'locations': locations,
            'diseases': diseases,
            'syndromes': syndromes
        }
        report_list.append(report)

        article = {
            'url': result[0],
            'date_of_publication': result[1].strftime("%c"),
            'headline': result[2],
            'main_text': result[3],
            'reports': report_list
        }

        result_list.append(article)

    db.close()

    return result_list