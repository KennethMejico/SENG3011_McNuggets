from helpers import noneOrEmpty, dates_not_given, addLog
from datetime import datetime
import json
import db_controller

def get_count(query_parameters):
    # Retrieve parameters
    if "start_date" in query_parameters:
        start_date = query_parameters['start_date']
    else:
        start_date = None
    if "end_date" in query_parameters:
        end_date = query_parameters['end_date']
    else:
        end_date = None
    if "key_terms" in query_parameters:
        key_terms = query_parameters['key_terms']
    else:
        key_terms = None

    if noneOrEmpty(start_date) or noneOrEmpty(end_date):
        return dates_not_given()

    start = datetime.strptime(start_date, '%Y-%m-%dT%H:%M:%S')
    end = datetime.strptime(end_date, '%Y-%m-%dT%H:%M:%S')
    if start > end:
        return dates_not_given()

    db = db_controller.getDbConnection()

    mycursor = db.cursor()

    # Base SQL Query
    sql = """
        select
            r.EventDate,
            d.DiseaseName,
            count(*)
        from Diseases d
        join Report_Diseases rd on rd.DiseaseID = d.DiseaseID
        join Reports r on rd.ReportID = r.ReportID
        where r.ReportID = r.ReportID
    """
    data = ()
    if not noneOrEmpty(start_date):
        # Convert start date time to datetime datatype
        start = datetime.strptime(start_date, '%Y-%m-%dT%H:%M:%S')
        sql = sql + " and r.EventDate >= %s"
        data = data + (start,)

    if not noneOrEmpty(end_date):
        end = datetime.strptime(end_date, '%Y-%m-%dT%H:%M:%S')
        sql = sql + " and r.EventDate <= %s"
        data = data + (end,)
    sql = sql + "group by d.DiseaseName"

    mycursor.execute(sql, data)
    results = mycursor.fetchall()
    diseases = {}
    for disease in results:
        diseases[disease[1]] = disease[2]

    # Return list of articles
    return json.dumps(addLog(diseases))