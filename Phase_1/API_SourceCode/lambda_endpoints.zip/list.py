import json
import db_controller
from datetime import datetime, timedelta
from search import search
from helpers import add, addLog

def home(params):
    return json.dumps(add({
        "function": "list",
        "endpoints": ["/diseases", "/locations", "/reports", "/syndromes"]
    }))

def get_all_reports(query_parameters):
    mydb = db_controller.getDbConnection()
    today = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S')
    result = search(yesterday, today, "", "", mydb)
    mydb.close()

    return json.dumps(add(result))

def get_all_diseases(query_parameters):
    db = db_controller.getDbConnection()
    cursor = db.cursor()

    query = "SELECT DiseaseName from Diseases"
    cursor.execute(query)
    results = cursor.fetchall()
    db.close()

    diseases = []
    for result in results:
        diseases.append(result[0])

    return json.dumps(add(diseases))

def get_all_syndromes(query_parameters):
    db = db_controller.getDbConnection()
    cursor = db.cursor()

    query = "SELECT SyndromeName from Syndromes"
    cursor.execute(query)
    results = cursor.fetchall()
    db.close()

    syndromes = []
    for result in results:
        syndromes.append(result[0])

    return json.dumps(add(syndromes))

def get_all_locations(query_parameters):
    db = db_controller.getDbConnection()
    cursor = db.cursor()

    query = "SELECT LocationName from Locations"
    cursor.execute(query)
    results = cursor.fetchall()
    db.close()

    locations = []
    for result in results:
        locations.append(result[0])

    return json.dumps(add(locations))

def get_all_keywords(query_parameters):
    db = db_controller.getDbConnection()
    cursor = db.cursor()

    query = "SELECT Keyword from Keywords"
    cursor.execute(query)
    results = cursor.fetchall()
    db.close()

    keywords = []
    for result in results:
        keywords.append(result[0])

    return json.dumps(add(keywords))